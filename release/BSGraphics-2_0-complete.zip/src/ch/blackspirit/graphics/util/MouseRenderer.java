package ch.blackspirit.graphics.util;

import ch.blackspirit.graphics.Graphics;
import ch.blackspirit.graphics.RealtimeCanvas;
import ch.blackspirit.graphics.View;
import ch.blackspirit.graphics.anim.Animation;

public class MouseRenderer {
	private final RealtimeCanvas realtimeCanvas;
	private final Mouse mouse;
	private Animation<?> animation;
	
	public MouseRenderer(RealtimeCanvas realtimeCanvas, Mouse mouse) {
		if (realtimeCanvas == null) throw new RuntimeException("realtime canvas must not be null");
//		if (mouse == null) throw new RuntimeException("mouse must not be null");
		this.realtimeCanvas = realtimeCanvas;
		this.mouse = mouse;
	}
	
	public void setAnimation(Animation<?> animation) {
		this.animation = animation;
	}
	public void draw(Graphics graphics, View view, float width, float height) {
		if (animation == null) return;
		int locationX = realtimeCanvas.getScreenLocationX();
		int locationY = realtimeCanvas.getScreenLocationY();
		int canvasWidth = realtimeCanvas.getWidth();
		int canvasHeight = realtimeCanvas.getHeight();
		
		int mouseX = mouse.getX();
		int mouseY = mouse.getY();
		
		int mouseRelativeX = mouseX - locationX;
		int mouseRelativeY = mouseY - locationY;
		
//		System.out.println(mouseRelativeX + ", " + mouseRelativeY);
		if (mouseRelativeX < 0 || mouseRelativeY < 0) return;
		if (mouseRelativeX >= canvasWidth || mouseRelativeY >= canvasHeight) return;
		
		float drawX = (view.getWidth() / canvasWidth) * mouseRelativeX;
		float drawY = (view.getHeight() / canvasHeight) * mouseRelativeY;
		
//		float translateX = (view.getWidth() / 2) + view.getCameraX() - drawX;
//		float translateY = (view.getHeight() / 2) + view.getCameraY() - drawY;

		float translateX = - drawX;
		float translateY = - drawY;

//		System.out.println("translate: " + translateX + ", " + translateY);
		
		graphics.translate(translateX, translateY);
		animation.draw(graphics, width, height);
	}
	public void update(long elapsedTime) {
		if (mouse != null) mouse.update();
		if (animation != null) {
			animation.update(elapsedTime);
		}
	}
	
	public static interface Mouse {
		public int getX();
		public int getY();
		
		public void update();
	}
}
